import Foundation
import AVFoundation
import CoreLocation

@MainActor
final class NavigationManager: NSObject, ObservableObject {
    @Published var currentInstruction = "Busca un destino para empezar"
    @Published var nextInstruction = ""
    @Published var remainingKm: Double = 0
    @Published var etaMinutes: Double = 0
    @Published var routeStarted = false
    @Published var offRoute = false
    @Published var recalculating = false
    @Published var voiceEnabled = true
    @Published var arrived = false
    @Published var currentManeuverDistanceM: Double = 0

    private let synthesizer = AVSpeechSynthesizer()
    private var steps: [RouteStep] = []
    private var stepIndex = 0
    private var geometry: [CLLocationCoordinate2D] = []
    private var destination: CLLocationCoordinate2D?
    private var routeDistanceM: Double = 0
    private var lastLocation: CLLocation?
    private var travelledAlongRouteM: Double = 0
    private var announcedStep = Set<Int>()

    let offRouteThresholdM: CLLocationDistance = 60
    let arrivalThresholdM: CLLocationDistance = 35

    func start(route: RouteResponse) {
        steps = route.steps
        geometry = route.geometry.coordinates2D
        stepIndex = 0
        routeDistanceM = polylineLength(geometry)
        travelledAlongRouteM = 0
        remainingKm = route.distanceKm
        etaMinutes = route.durationMin
        destination = geometry.last
        routeStarted = true
        arrived = false
        offRoute = false
        recalculating = false
        lastLocation = nil
        announcedStep.removeAll()
        updateInstruction(speak: true)
    }

    func stop() {
        routeStarted = false
        recalculating = false
        synthesizer.stopSpeaking(at: .immediate)
        currentInstruction = "Navegación detenida"
        nextInstruction = ""
        currentManeuverDistanceM = 0
    }

    func setRecalculating(_ value: Bool) { recalculating = value }

    func update(location: CLLocation) {
        guard routeStarted, !arrived else { return }
        if let previous = lastLocation {
            let delta = location.distance(from: previous)
            if delta < 300 { travelledAlongRouteM += delta }
        }
        lastLocation = location

        let nearest = nearestPoint(on: geometry, to: location.coordinate)
        offRoute = nearest.distance > offRouteThresholdM

        if let destination {
            let destinationDistance = location.distance(from: CLLocation(latitude: destination.latitude, longitude: destination.longitude))
            if destinationDistance <= arrivalThresholdM {
                arrived = true
                routeStarted = false
                offRoute = false
                currentInstruction = "Has llegado a tu destino 🏁"
                nextInstruction = ""
                currentManeuverDistanceM = 0
                speakText(currentInstruction)
                return
            }
        }

        while stepIndex < steps.count {
            guard let point = steps[stepIndex].location, point.count >= 2 else { stepIndex += 1; continue }
            let maneuver = CLLocation(latitude: point[1], longitude: point[0])
            let distance = location.distance(from: maneuver)
            currentManeuverDistanceM = distance
            let threshold = location.speed > 15 ? 75.0 : 45.0

            if distance <= 20 && !announcedStep.contains(stepIndex) {
                announcedStep.insert(stepIndex)
                speakText(steps[stepIndex].maneuver?.instruction ?? steps[stepIndex].name)
            }
            if distance <= threshold {
                stepIndex += 1
                updateInstruction(speak: false)
                continue
            }
            break
        }

        let remaining = max(0, routeDistanceM - travelledAlongRouteM)
        remainingKm = remaining / 1000
        if location.speed > 2 {
            etaMinutes = remaining / location.speed / 60
        }
    }

    func destinationCoordinate() -> CLLocationCoordinate2D? { destination }

    private func updateInstruction(speak: Bool) {
        guard stepIndex < steps.count else {
            currentInstruction = "Sigue la carretera hasta el destino"
            nextInstruction = "Último tramo"
            if speak { speakText(currentInstruction) }
            return
        }
        let step = steps[stepIndex]
        currentInstruction = step.maneuver?.instruction ?? step.name
        nextInstruction = stepIndex + 1 < steps.count ? "Después: " + (steps[stepIndex + 1].maneuver?.instruction ?? steps[stepIndex + 1].name) : "Último tramo"
        if speak { speakText(currentInstruction) }
    }

    private func speakText(_ text: String) {
        guard voiceEnabled, !text.isEmpty else { return }
        synthesizer.stopSpeaking(at: .word)
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "es-ES")
        utterance.rate = 0.48
        utterance.preUtteranceDelay = 0.05
        synthesizer.speak(utterance)
    }

    private func polylineLength(_ points: [CLLocationCoordinate2D]) -> Double {
        guard points.count > 1 else { return 0 }
        return zip(points, points.dropFirst()).reduce(0) { sum, pair in
            sum + CLLocation(latitude: pair.0.latitude, longitude: pair.0.longitude).distance(from: CLLocation(latitude: pair.1.latitude, longitude: pair.1.longitude))
        }
    }

    private func nearestPoint(on points: [CLLocationCoordinate2D], to coordinate: CLLocationCoordinate2D) -> (point: CLLocationCoordinate2D, distance: CLLocationDistance) {
        guard points.count > 1 else {
            let p = points.first ?? coordinate
            return (p, CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude).distance(from: CLLocation(latitude: p.latitude, longitude: p.longitude)))
        }
        let target = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        var best = (points[0], CLLocationDistance.greatestFiniteMagnitude)
        for pair in zip(points, points.dropFirst()) {
            let projected = project(coordinate, onto: pair.0, pair.1)
            let distance = target.distance(from: CLLocation(latitude: projected.latitude, longitude: projected.longitude))
            if distance < best.1 { best = (projected, distance) }
        }
        return best
    }

    private func project(_ p: CLLocationCoordinate2D, onto a: CLLocationCoordinate2D, _ b: CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        let latScale = 111_320.0
        let lonScale = max(1.0, 111_320.0 * cos(a.latitude * .pi / 180))
        let px = (p.longitude - a.longitude) * lonScale
        let py = (p.latitude - a.latitude) * latScale
        let bx = (b.longitude - a.longitude) * lonScale
        let by = (b.latitude - a.latitude) * latScale
        let denom = bx * bx + by * by
        let t = denom == 0 ? 0 : max(0, min(1, (px * bx + py * by) / denom))
        return CLLocationCoordinate2D(latitude: a.latitude + (by * t) / latScale, longitude: a.longitude + (bx * t) / lonScale)
    }
}
