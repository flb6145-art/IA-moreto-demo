import Foundation
import MapKit

@MainActor
final class ServicesManager: ObservableObject {
    @Published var results: [MKMapItem] = []
    @Published var isSearching = false
    @Published var selectedType = ""

    func clear() { results = []; selectedType = "" }

    func search(type: String, along coordinates: [CLLocationCoordinate2D]) async {
        guard !coordinates.isEmpty else { return }
        isSearching = true
        selectedType = type
        defer { isSearching = false }

        let sample = samplePoints(coordinates, maxCount: 5)
        var found: [MKMapItem] = []
        await withTaskGroup(of: [MKMapItem].self) { group in
            for point in sample {
                group.addTask {
                    let request = MKLocalSearch.Request()
                    request.naturalLanguageQuery = type
                    request.region = MKCoordinateRegion(center: point, latitudinalMeters: 6000, longitudinalMeters: 6000)
                    do { return try await MKLocalSearch(request: request).start().mapItems }
                    catch { return [] }
                }
            }
            for await items in group { found.append(contentsOf: items) }
        }

        var seen = Set<String>()
        results = found.filter { item in
            let key = "\(item.name ?? "")|\(item.placemark.coordinate.latitude.rounded(toPlaces: 5))|\(item.placemark.coordinate.longitude.rounded(toPlaces: 5))"
            return seen.insert(key).inserted
        }.prefix(12).map { $0 }
    }

    private func samplePoints(_ points: [CLLocationCoordinate2D], maxCount: Int) -> [CLLocationCoordinate2D] {
        guard points.count > maxCount else { return points }
        return (0..<maxCount).map { i in points[Int(Double(points.count - 1) * Double(i) / Double(maxCount - 1))] }
    }
}

private extension Double {
    func rounded(toPlaces places: Int) -> Double {
        let p = pow(10.0, Double(places))
        return (self * p).rounded() / p
    }
}
