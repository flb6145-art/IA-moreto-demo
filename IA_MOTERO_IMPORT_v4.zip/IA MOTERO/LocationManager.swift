import Foundation
import CoreLocation

@MainActor
final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var coordinate: CLLocationCoordinate2D?
    @Published var speedKmh: Double = 0
    @Published var track: [CLLocationCoordinate2D] = []
    @Published var authorizationDenied = false
    @Published var authorizationNeedsAlways = false

    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        manager.activityType = .automotiveNavigation
        manager.distanceFilter = 5
        manager.allowsBackgroundLocationUpdates = true
        manager.pausesLocationUpdatesAutomatically = false
    }

    func requestPermission() { manager.requestWhenInUseAuthorization() }
    func requestAlwaysPermission() { manager.requestAlwaysAuthorization() }

    func start() {
        track.removeAll(keepingCapacity: true)
        let status = manager.authorizationStatus
        if status == .notDetermined { manager.requestWhenInUseAuthorization(); return }
        if status == .authorizedWhenInUse { authorizationNeedsAlways = true }
        guard status == .authorizedWhenInUse || status == .authorizedAlways else { return }
        manager.startUpdatingLocation()
    }

    func stop() { manager.stopUpdatingLocation() }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        authorizationDenied = status == .denied || status == .restricted
        authorizationNeedsAlways = status == .authorizedWhenInUse
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last, location.horizontalAccuracy >= 0, location.horizontalAccuracy <= 80 else { return }
        coordinate = location.coordinate
        speedKmh = max(0, location.speed * 3.6)
        if track.last.map({ CLLocation(latitude: $0.latitude, longitude: $0.longitude).distance(from: location) > 3 }) ?? true {
            track.append(location.coordinate)
        }
    }
}
