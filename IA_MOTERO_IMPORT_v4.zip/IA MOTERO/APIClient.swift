import Foundation
import CoreLocation

final class APIClient {
    static let shared = APIClient()
    var baseURL = URL(string: "https://api.example.com")!
    var isConfigured: Bool { baseURL.host != "api.example.com" }

    func calculateRoute(points: [CLLocationCoordinate2D], preferences: RoutePreferences) async throws -> RouteResponse {
        let url = baseURL.appendingPathComponent("api/route")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body = RouteRequest(points: points.map { ["lat": $0.latitude, "lon": $0.longitude] }, preferences: preferences)
        request.httpBody = try JSONEncoder().encode(body)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw URLError(.badServerResponse) }
        return try JSONDecoder().decode(RouteResponse.self, from: data)
    }

    func recalculate(current: CLLocationCoordinate2D, destination: CLLocationCoordinate2D, avoidHighways: Bool = true) async throws -> RouteResponse {
        guard isConfigured else { throw URLError(.badURL) }
        let url = baseURL.appendingPathComponent("api/route/recalculate")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = [
            "current": ["lat": current.latitude, "lon": current.longitude],
            "destination": ["lat": destination.latitude, "lon": destination.longitude],
            "preferences": ["avoidHighways": avoidHighways]
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw URLError(.badServerResponse) }
        return try JSONDecoder().decode(RouteResponse.self, from: data)
    }
}
