import SwiftUI

@main
struct IAMoteroApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
