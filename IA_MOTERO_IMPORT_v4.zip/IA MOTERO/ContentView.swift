import SwiftUI
import MapKit
import CoreLocation

struct ContentView: View {
    @StateObject private var location = LocationManager()
    @StateObject private var navigation = NavigationManager()
    @StateObject private var planner = RoutePlanner()
    @StateObject private var speech = SpeechManager()
    @StateObject private var services = ServicesManager()
    @StateObject private var routeImporter = RouteImportManager()

    @State private var route: RouteResponse?
    @State private var destination: CLLocationCoordinate2D?
    @State private var destinationName = ""
    @State private var stops: [CLLocationCoordinate2D] = []
    @State private var stopNames: [String] = []
    @State private var query = ""
    @State private var camera: MapCameraPosition = .automatic
    @State private var preferences = RoutePreferences()
    @State private var showPreferences = false
    @State private var searchResults: [MKMapItem] = []
    @State private var errorMessage: String?
    @State private var addingStop = false
    @State private var rerouteTaskRunning = false
    @State private var showServices = false
    @State private var showRouteImporter = false

    var body: some View {
        ZStack(alignment: .top) {
            Map(position: $camera) {
                UserAnnotation()
                if let route {
                    MapPolyline(coordinates: route.geometry.coordinates2D).stroke(.orange, lineWidth: navigation.routeStarted ? 8 : 6)
                }
                if !location.track.isEmpty && navigation.routeStarted {
                    MapPolyline(coordinates: location.track).stroke(.blue, lineWidth: 4)
                }
                ForEach(Array(stops.enumerated()), id: \.offset) { index, point in
                    Marker("Parada \(index + 1)", systemImage: "flag.fill", coordinate: point).tint(.blue)
                }
                if let destination {
                    Marker(destinationName.isEmpty ? "Destino" : destinationName, systemImage: "flag.checkered", coordinate: destination).tint(.orange)
                }
                ForEach(Array(services.results.enumerated()), id: \.offset) { _, item in
                    Marker(item.name ?? "Servicio", systemImage: serviceIcon(for: services.selectedType), coordinate: item.placemark.coordinate).tint(.green)
                }
            }
            .mapControls { MapUserLocationButton(); MapCompass(); MapScaleView() }
            .ignoresSafeArea()

            VStack(spacing: 10) {
                if location.authorizationDenied {
                    Label("Activa la ubicación en Ajustes para navegar", systemImage: "location.slash.fill")
                        .font(.caption.bold()).padding(9).background(.red.opacity(0.9), in: Capsule()).foregroundStyle(.white)
                } else if location.authorizationNeedsAlways && navigation.routeStarted {
                    Button { location.requestAlwaysPermission() } label: {
                        Label("Permitir ubicación en segundo plano", systemImage: "location.fill")
                    }.font(.caption.bold()).buttonStyle(.borderedProminent)
                }
                searchPanel
                if addingStop {
                    Label("Modo: añadir parada", systemImage: "plus.circle.fill")
                        .font(.caption.bold())
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(.blue.opacity(0.9), in: Capsule())
                        .foregroundStyle(.white)
                }
                if !searchResults.isEmpty && !navigation.routeStarted { resultsPanel }
            }
            .padding(.top, 8)

            if navigation.routeStarted || navigation.arrived {
                navigationPanel
            } else if let route {
                routeSummary(route)
            }

            if services.isSearching {
                ProgressView("Buscando servicios…")
                    .padding(.horizontal, 18).padding(.vertical, 12)
                    .background(.regularMaterial, in: Capsule())
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            } else if showServices && !services.results.isEmpty && !navigation.routeStarted {
                servicesPanel
            }

            if planner.isCalculating {
                ProgressView("Calculando ruta…")
                    .padding(.horizontal, 18).padding(.vertical, 12)
                    .background(.regularMaterial, in: Capsule())
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            }
        }
        .sheet(isPresented: $showPreferences) { preferencesSheet }
        .fileImporter(isPresented: $showRouteImporter, allowedContentTypes: [.gpx, .kml, .tcx, .geoJSON], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let url = urls.first else { return }
                Task { await importRoute(from: url) }
            case .failure(let error):
                errorMessage = error.localizedDescription
            }
        }
        .task {
            location.requestPermission()
            await speech.requestPermission()
        }
        .onChange(of: speech.transcript) { _, value in
            if !value.isEmpty && !speech.listening {
                query = value
                Task { await search(query: value) }
            }
        }
        .onReceive(location.$coordinate) { coordinate in
            guard let coordinate else { return }
            let loc = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
            navigation.update(location: loc)
            if navigation.offRoute && navigation.routeStarted && !rerouteTaskRunning {
                Task { await rerouteLocally(from: coordinate) }
            }
        }
        .alert("IA MOTERO", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
            Button("OK") { errorMessage = nil }
        } message: { Text(errorMessage ?? "") }
    }

    private var searchPanel: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField(addingStop ? "Busca una parada" : "¿A dónde vamos?", text: $query)
                .textInputAutocapitalization(.sentences)
                .submitLabel(.search)
                .onSubmit { Task { await search(query: query) } }
            Button { if speech.listening { speech.stop() } else { speech.start() } } label: {
                Image(systemName: speech.listening ? "waveform.circle.fill" : "mic.fill").font(.title3)
            }
            if destination != nil && !navigation.routeStarted {
                Button { addingStop.toggle() } label: { Image(systemName: addingStop ? "xmark.circle.fill" : "plus.circle.fill").font(.title3) }
            }
            Button { showRouteImporter = true } label: { Image(systemName: "square.and.arrow.down") }
                .accessibilityLabel("Importar ruta")
            Button { showPreferences = true } label: { Image(systemName: "slider.horizontal.3") }
        }
        .padding(13)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
        .padding(.horizontal)
    }

    private var resultsPanel: some View {
        VStack(spacing: 0) {
            ForEach(Array(searchResults.prefix(5).enumerated()), id: \.offset) { _, item in
                Button { choose(item) } label: {
                    HStack {
                        Image(systemName: "mappin.circle.fill").foregroundStyle(.orange)
                        VStack(alignment: .leading) {
                            Text(item.name ?? "Destino").font(.headline)
                            Text(item.placemark.title ?? "").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(); Image(systemName: "chevron.right").foregroundStyle(.secondary)
                    }.padding(12)
                }
                Divider()
            }
        }
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
        .padding(.horizontal)
    }

    private func routeSummary(_ route: RouteResponse) -> some View {
        VStack(spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(destinationName.isEmpty ? "Ruta preparada" : destinationName).font(.headline)
                    Text("\(route.distanceKm, specifier: "%.0f") km · \(route.durationMin, specifier: "%.0f") min · \(stops.count) paradas")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                Button { startNavigation() } label: { Label("Empezar", systemImage: "arrow.triangle.turn.up.right.diamond.fill") }
                    .buttonStyle(.borderedProminent)
            }
            HStack(spacing: 8) {
                Button("Añadir parada") { addingStop = true }
                Button("Servicios") { showServices = true; Task { await services.search(type: "gasolinera", along: route.geometry.coordinates2D) } }
                Button("Nueva") { resetRoute() }
            }
            .font(.caption)
            .buttonStyle(.bordered)
        }
        .padding()
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
        .padding()
        .frame(maxHeight: .infinity, alignment: .bottom)
    }

    private var navigationPanel: some View {
        VStack(spacing: 10) {
            HStack(alignment: .top) {
                Image(systemName: "arrow.turn.up.right.circle.fill").font(.largeTitle).foregroundStyle(.orange)
                VStack(alignment: .leading, spacing: 3) {
                    Text(navigation.currentInstruction).font(.title3.bold()).lineLimit(2)
                    if navigation.currentManeuverDistanceM > 0 { Text("En \(Int(navigation.currentManeuverDistanceM)) m").font(.caption).foregroundStyle(.orange) }
                    Text(navigation.nextInstruction).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
            }
            HStack {
                stat("\(Int(location.speedKmh))", "km/h")
                stat("\(navigation.remainingKm, specifier: "%.1f")", "km")
                stat("\(navigation.etaMinutes, specifier: "%.0f")", "min")
                Button { navigation.voiceEnabled.toggle() } label: { Image(systemName: navigation.voiceEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill") }.buttonStyle(.bordered)
            }
            if navigation.recalculating { ProgressView("Recalculando…").frame(maxWidth: .infinity) }
            if navigation.offRoute && !navigation.recalculating {
                Label("Fuera de ruta · recalculando", systemImage: "exclamationmark.triangle.fill")
                    .font(.caption.bold()).frame(maxWidth: .infinity).padding(8)
                    .background(.red.opacity(0.85), in: RoundedRectangle(cornerRadius: 10))
            }
            HStack {
                Button { Task { await services.search(type: "gasolinera", along: route?.geometry.coordinates2D ?? []) } } label: { Label("Gas", systemImage: "fuelpump.fill") }
                Button { Task { await services.search(type: "restaurante", along: route?.geometry.coordinates2D ?? []) } } label: { Label("Comer", systemImage: "fork.knife") }
                Button { Task { await services.search(type: "taller de motos", along: route?.geometry.coordinates2D ?? []) } } label: { Label("Taller", systemImage: "wrench.and.screwdriver.fill") }
            }.font(.caption).buttonStyle(.bordered)
            Button(navigation.arrived ? "Nueva ruta" : "Terminar navegación") {
                navigation.stop(); location.stop(); if navigation.arrived { resetRoute() }
            }.buttonStyle(.bordered)
        }
        .padding()
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 22))
        .padding()
        .frame(maxHeight: .infinity, alignment: .bottom)
    }

    private var servicesPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Text(services.selectedType.capitalized).font(.headline); Spacer(); Button("Cerrar") { showServices = false; services.clear() } }
            ForEach(Array(services.results.prefix(5).enumerated()), id: \.offset) { _, item in
                Button {
                    camera = .region(MKCoordinateRegion(center: item.placemark.coordinate, latitudinalMeters: 1200, longitudinalMeters: 1200))
                } label: {
                    HStack { Image(systemName: serviceIcon(for: services.selectedType)); VStack(alignment: .leading) { Text(item.name ?? "Servicio").font(.subheadline.bold()); Text(item.placemark.title ?? "").font(.caption).foregroundStyle(.secondary).lineLimit(1) }; Spacer() }
                }
            }
        }
        .padding()
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 18))
        .padding()
        .frame(maxHeight: .infinity, alignment: .top)
        .padding(.top, 90)
    }

    private var preferencesSheet: some View {
        NavigationStack {
            Form {
                Section("Cómo quieres conducir") {
                    Toggle("Evitar autopistas", isOn: $preferences.avoidHighways)
                    Toggle("Evitar peajes", isOn: $preferences.avoidTolls)
                    Toggle("Buscar carreteras con curvas", isOn: $preferences.windingRoads)
                    Toggle("Ruta panorámica", isOn: $preferences.scenic)
                    Toggle("Priorizar rapidez", isOn: $preferences.fastest)
                }
                Section("IA MOTERO") {
                    Text("Las opciones de curvas y panorámica quedan preparadas para el motor específico de IA MOTERO. El cálculo local usa MapKit como respaldo fiable.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Preferencias")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Listo") { showPreferences = false } } }
        }
    }

    private func stat(_ value: String, _ label: String) -> some View {
        VStack { Text(value).font(.title2.bold()); Text(label).font(.caption).foregroundStyle(.secondary) }.frame(maxWidth: .infinity)
    }

    private func search(query: String) async {
        let clean = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        let request = MKLocalSearch.Request(); request.naturalLanguageQuery = clean
        if let center = location.coordinate { request.region = MKCoordinateRegion(center: center, latitudinalMeters: 100_000, longitudinalMeters: 100_000) }
        do { searchResults = try await MKLocalSearch(request: request).start().mapItems }
        catch { errorMessage = "No se ha encontrado el destino." }
    }

    private func choose(_ item: MKMapItem) {
        let point = item.placemark.coordinate
        if addingStop, destination != nil {
            stops.append(point); stopNames.append(item.name ?? "Parada")
            addingStop = false
            query = destinationName
            searchResults = []
            Task { await buildRoute() }
            return
        }
        destination = point; destinationName = item.name ?? "Destino"; query = destinationName; searchResults = []; stops = []; stopNames = []; addingStop = false
        camera = .region(MKCoordinateRegion(center: point, latitudinalMeters: 20_000, longitudinalMeters: 20_000))
        Task { await buildRoute() }
    }

    private func buildRoute() async {
        guard let destination else { return }
        let origin = location.coordinate
        guard let origin else { errorMessage = "Activa la ubicación para calcular la ruta."; return }
        var points = [origin]; points.append(contentsOf: stops); points.append(destination)
        if APIClient.shared.isConfigured {
            do { route = try await APIClient.shared.calculateRoute(points: points, preferences: preferences); return } catch { }
        }
        route = await planner.calculate(points: points, preferences: preferences)
        if route == nil { errorMessage = planner.errorMessage ?? "No se pudo calcular la ruta." }
    }

    private func startNavigation() {
        guard let route else { return }
        services.clear(); showServices = false
        navigation.start(route: route); location.start()
        if let first = route.geometry.coordinates2D.first { camera = .region(MKCoordinateRegion(center: first, latitudinalMeters: 1500, longitudinalMeters: 1500)) }
    }

    private func rerouteLocally(from coordinate: CLLocationCoordinate2D) async {
        guard !rerouteTaskRunning, navigation.routeStarted, let destination = navigation.destinationCoordinate() else { return }
        rerouteTaskRunning = true; navigation.setRecalculating(true)
        defer { rerouteTaskRunning = false; navigation.setRecalculating(false) }
        var points = [coordinate]; points.append(contentsOf: stops); points.append(destination)
        if let newRoute = await planner.calculate(points: points, preferences: preferences) {
            route = newRoute
            navigation.start(route: newRoute)
        }
    }


    private func importRoute(from url: URL) async {
        do {
            let imported = try await routeImporter.importFile(url: url)
            let coords = imported.coordinates
            guard coords.count >= 2 else { throw RouteImportError.invalidRoute }
            let geometry = Geometry(type: "LineString", coordinates: coords.map { [$0.longitude, $0.latitude] })
            let totalDistance = zip(coords, coords.dropFirst()).reduce(0.0) { partial, pair in
                partial + CLLocation(latitude: pair.0.latitude, longitude: pair.0.longitude).distance(from: CLLocation(latitude: pair.1.latitude, longitude: pair.1.longitude))
            }
            let averageSpeedMPS = 55.0 / 3.6
            let steps = makeImportedSteps(coords)
            route = RouteResponse(distanceKm: totalDistance / 1000.0, durationMin: totalDistance / averageSpeedMPS / 60.0, geometry: geometry, steps: steps)
            destination = coords.last
            destinationName = imported.name.isEmpty ? "Ruta importada" : imported.name
            query = destinationName
            stops = imported.waypoints.dropLast().map(\.coordinate)
            stopNames = imported.waypoints.dropLast().map(\.name)
            searchResults = []
            addingStop = false
            camera = .region(MKCoordinateRegion(center: coords[coords.count / 2], latitudinalMeters: max(2500, totalDistance * 0.6), longitudinalMeters: max(2500, totalDistance * 0.6)))
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func makeImportedSteps(_ coords: [CLLocationCoordinate2D]) -> [RouteStep] {
        guard !coords.isEmpty else { return [] }
        let stride = max(1, coords.count / 12)
        var result: [RouteStep] = []
        for index in stride(from: 0, to: coords.count, by: stride) {
            let point = coords[index]
            result.append(RouteStep(name: index == 0 ? "Inicio de la ruta importada" : "Continúa por la ruta importada", distance: 0, duration: 0, maneuver: Maneuver(instruction: index == 0 ? "Comienza la ruta importada" : "Continúa por la ruta importada", type: "imported", modifier: nil), location: [point.longitude, point.latitude]))
        }
        if let last = coords.last {
            result.append(RouteStep(name: "Llegada", distance: 0, duration: 0, maneuver: Maneuver(instruction: "Has llegado al final de la ruta", type: "arrive", modifier: nil), location: [last.longitude, last.latitude]))
        }
        return result
    }

    private func resetRoute() {
        navigation.stop(); location.stop(); route = nil; destination = nil; destinationName = ""; query = ""; stops = []; stopNames = []; searchResults = []; services.clear(); showServices = false
    }

    private func serviceIcon(for type: String) -> String {
        if type.contains("gas") { return "fuelpump.fill" }
        if type.contains("rest") { return "fork.knife" }
        return "wrench.and.screwdriver.fill"
    }
}

#Preview { ContentView() }
