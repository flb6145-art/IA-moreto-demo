import Foundation
import CoreLocation
import MapKit
import UniformTypeIdentifiers

struct RouteResponse: Codable {
    let distanceKm: Double
    let durationMin: Double
    let geometry: Geometry
    let steps: [RouteStep]
}

struct Geometry: Codable {
    let type: String
    let coordinates: [[Double]] // [longitude, latitude]
}

struct RouteStep: Codable, Identifiable {
    var id = UUID()
    let name: String
    let distance: Double
    let duration: Double
    let maneuver: Maneuver?
    let location: [Double]?

    enum CodingKeys: String, CodingKey { case name, distance, duration, maneuver, location }
}

struct Maneuver: Codable {
    let instruction: String?
    let type: String?
    let modifier: String?
}

struct RoutePreferences: Codable, Equatable {
    var avoidHighways = true
    var avoidTolls = false
    var windingRoads = true
    var scenic = false
    var fastest = false
}

struct RouteRequest: Codable {
    let points: [[String: Double]]
    let preferences: RoutePreferences
}

struct ServicePoint: Identifiable, Codable {
    let id: String
    let name: String
    let type: String
    let latitude: Double
    let longitude: Double
    let distanceFromRouteM: Double
}

extension Geometry {
    var coordinates2D: [CLLocationCoordinate2D] {
        coordinates.compactMap { pair in
            guard pair.count >= 2 else { return nil }
            return CLLocationCoordinate2D(latitude: pair[1], longitude: pair[0])
        }
    }
}

extension RouteResponse {
    static func from(mapRoute: MKRoute) -> RouteResponse {
        let coords = mapRoute.polyline.points().map { $0.coordinate }
        let geometry = Geometry(type: "LineString", coordinates: coords.map { [$0.longitude, $0.latitude] })
        let steps = mapRoute.steps.filter { !$0.instructions.isEmpty }.map { step in
            let c = step.polyline.points().first?.coordinate ?? coords.first ?? CLLocationCoordinate2D()
            return RouteStep(
                name: step.instructions,
                distance: step.distance,
                duration: step.expectedTravelTime,
                maneuver: Maneuver(instruction: step.instructions, type: nil, modifier: nil),
                location: [c.longitude, c.latitude]
            )
        }
        return RouteResponse(distanceKm: mapRoute.distance / 1000, durationMin: mapRoute.expectedTravelTime / 60, geometry: geometry, steps: steps)
    }
}

extension UTType {
    static let gpx = UTType(exportedAs: "com.iamotero.gpx", conformingTo: .xml)
    static let kml = UTType(exportedAs: "com.iamotero.kml", conformingTo: .xml)
    static let tcx = UTType(exportedAs: "com.iamotero.tcx", conformingTo: .xml)
    static let geoJSON = UTType(exportedAs: "com.iamotero.geojson", conformingTo: .json)
}
