import Foundation
import CoreLocation
import Combine

struct ImportedRoute {
    let name: String
    let coordinates: [CLLocationCoordinate2D]
    let waypoints: [ImportedWaypoint]
    let sourceFormat: String
}

struct ImportedWaypoint {
    let name: String
    let coordinate: CLLocationCoordinate2D
}

enum RouteImportError: LocalizedError {
    case unsupportedFormat
    case invalidRoute
    case unreadableFile

    var errorDescription: String? {
        switch self {
        case .unsupportedFormat: return "Formato de navegación no compatible."
        case .invalidRoute: return "El archivo no contiene una ruta válida con suficientes coordenadas."
        case .unreadableFile: return "No se ha podido leer el archivo."
        }
    }
}

@MainActor
final class RouteImportManager: NSObject, ObservableObject {
    @Published private(set) var lastImported: ImportedRoute?

    func importFile(url: URL) async throws -> ImportedRoute {
        let secured = url.startAccessingSecurityScopedResource()
        defer { if secured { url.stopAccessingSecurityScopedResource() } }

        let data: Data
        do { data = try Data(contentsOf: url) }
        catch { throw RouteImportError.unreadableFile }

        let ext = url.pathExtension.lowercased()
        let imported: ImportedRoute
        switch ext {
        case "gpx": imported = try parseGPX(data, fallbackName: url.deletingPathExtension().lastPathComponent)
        case "kml": imported = try parseKML(data, fallbackName: url.deletingPathExtension().lastPathComponent)
        case "tcx": imported = try parseTCX(data, fallbackName: url.deletingPathExtension().lastPathComponent)
        case "geojson", "json": imported = try parseGeoJSON(data, fallbackName: url.deletingPathExtension().lastPathComponent)
        default: throw RouteImportError.unsupportedFormat
        }

        guard imported.coordinates.count >= 2 else { throw RouteImportError.invalidRoute }
        lastImported = imported
        return imported
    }

    private func parseGPX(_ data: Data, fallbackName: String) throws -> ImportedRoute {
        let parser = XMLParser(data: data)
        let delegate = GPXDelegate()
        parser.delegate = delegate
        guard parser.parse() else { throw RouteImportError.invalidRoute }
        let points = delegate.trackPoints.isEmpty ? delegate.routePoints : delegate.trackPoints
        guard points.count >= 2 else { throw RouteImportError.invalidRoute }
        return ImportedRoute(name: delegate.routeName ?? fallbackName, coordinates: points, waypoints: delegate.waypoints, sourceFormat: "GPX")
    }

    private func parseTCX(_ data: Data, fallbackName: String) throws -> ImportedRoute {
        let parser = XMLParser(data: data)
        let delegate = TCXDelegate()
        parser.delegate = delegate
        guard parser.parse() else { throw RouteImportError.invalidRoute }
        guard delegate.points.count >= 2 else { throw RouteImportError.invalidRoute }
        return ImportedRoute(name: delegate.routeName ?? fallbackName, coordinates: delegate.points, waypoints: [], sourceFormat: "TCX")
    }

    private func parseKML(_ data: Data, fallbackName: String) throws -> ImportedRoute {
        let parser = XMLParser(data: data)
        let delegate = KMLDelegate()
        parser.delegate = delegate
        guard parser.parse() else { throw RouteImportError.invalidRoute }
        guard delegate.coordinates.count >= 2 else { throw RouteImportError.invalidRoute }
        return ImportedRoute(name: delegate.routeName ?? fallbackName, coordinates: delegate.coordinates, waypoints: delegate.waypoints, sourceFormat: "KML")
    }

    private func parseGeoJSON(_ data: Data, fallbackName: String) throws -> ImportedRoute {
        let object = try JSONSerialization.jsonObject(with: data)
        var coordinates: [CLLocationCoordinate2D] = []
        var waypoints: [ImportedWaypoint] = []
        var name = fallbackName

        func addLine(_ value: Any) {
            guard let array = value as? [Any] else { return }
            for item in array {
                if let pair = item as? [Any], pair.count >= 2,
                   let lon = pair[0] as? Double, let lat = pair[1] as? Double {
                    coordinates.append(CLLocationCoordinate2D(latitude: lat, longitude: lon))
                } else { addLine(item) }
            }
        }

        func inspect(_ value: Any) {
            guard let dict = value as? [String: Any] else { return }
            if let properties = dict["properties"] as? [String: Any], let n = properties["name"] as? String, !n.isEmpty { name = n }
            if let n = dict["name"] as? String, !n.isEmpty { name = n }
            if let geometry = dict["geometry"] as? [String: Any] {
                let type = (geometry["type"] as? String) ?? ""
                if let coords = geometry["coordinates"] {
                    switch type {
                    case "LineString": addLine(coords)
                    case "MultiLineString": addLine(coords)
                    case "Point":
                        if let pair = coords as? [Any], pair.count >= 2, let lon = pair[0] as? Double, let lat = pair[1] as? Double {
                            waypoints.append(ImportedWaypoint(name: name, coordinate: CLLocationCoordinate2D(latitude: lat, longitude: lon)))
                        }
                    default: addLine(coords)
                    }
                }
            }
            if let features = dict["features"] as? [Any] { features.forEach(inspect) }
        }

        inspect(object)
        guard coordinates.count >= 2 else { throw RouteImportError.invalidRoute }
        return ImportedRoute(name: name, coordinates: coordinates, waypoints: waypoints, sourceFormat: "GeoJSON")
    }
}

private final class GPXDelegate: NSObject, XMLParserDelegate {
    var trackPoints: [CLLocationCoordinate2D] = []
    var routePoints: [CLLocationCoordinate2D] = []
    var waypoints: [ImportedWaypoint] = []
    var routeName: String?
    private var element = ""
    private var buffer = ""
    private var currentPoint: CLLocationCoordinate2D?
    private var currentPointName = ""
    private var inTrack = false
    private var inRoute = false

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        element = elementName.lowercased()
        buffer = ""
        if element == "trkseg" { inTrack = true }
        if element == "rte" { inRoute = true }
        if ["trkpt", "rtept", "wpt"].contains(element), let lat = Double(attributeDict["lat"] ?? ""), let lon = Double(attributeDict["lon"] ?? "") {
            currentPoint = CLLocationCoordinate2D(latitude: lat, longitude: lon); currentPointName = ""
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) { buffer += string }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        let name = elementName.lowercased()
        let value = buffer.trimmingCharacters(in: .whitespacesAndNewlines)
        if name == "name", !value.isEmpty {
            if currentPoint != nil { currentPointName = value } else if routeName == nil { routeName = value }
        }
        if name == "trkpt", let point = currentPoint { trackPoints.append(point); currentPoint = nil }
        if name == "rtept", let point = currentPoint { routePoints.append(point); currentPoint = nil }
        if name == "wpt", let point = currentPoint { waypoints.append(ImportedWaypoint(name: currentPointName.isEmpty ? "Punto" : currentPointName, coordinate: point)); currentPoint = nil }
        if name == "trkseg" { inTrack = false }
        if name == "rte" { inRoute = false }
        buffer = ""; element = ""
    }
}

private final class TCXDelegate: NSObject, XMLParserDelegate {
    var points: [CLLocationCoordinate2D] = []
    var routeName: String?
    private var element = ""
    private var buffer = ""
    private var lat: Double?
    private var lon: Double?

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        element = elementName.lowercased(); buffer = ""
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) { buffer += string }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        let name = elementName.lowercased(); let value = buffer.trimmingCharacters(in: .whitespacesAndNewlines)
        if name == "name", routeName == nil, !value.isEmpty { routeName = value }
        if name == "latitude", let v = Double(value) { lat = v }
        if name == "longitude", let v = Double(value) { lon = v }
        if name == "trackpoint", let lat, let lon { points.append(CLLocationCoordinate2D(latitude: lat, longitude: lon)); self.lat = nil; self.lon = nil }
        buffer = ""; element = ""
    }
}

private final class KMLDelegate: NSObject, XMLParserDelegate {
    var coordinates: [CLLocationCoordinate2D] = []
    var waypoints: [ImportedWaypoint] = []
    var routeName: String?
    private var element = ""
    private var buffer = ""
    private var currentName = ""
    private var inLineString = false

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        element = elementName.lowercased(); buffer = ""
        if element == "linestring" { inLineString = true }
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) { buffer += string }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        let name = elementName.lowercased(); let value = buffer.trimmingCharacters(in: .whitespacesAndNewlines)
        if name == "name", !value.isEmpty { currentName = value; if routeName == nil { routeName = value } }
        if name == "coordinates" {
            let points = value.split { $0 == " " || $0 == "\n" || $0 == "\r" || $0 == "\t" }.compactMap { token -> CLLocationCoordinate2D? in
                let p = token.split(separator: ","); guard p.count >= 2, let lon = Double(p[0]), let lat = Double(p[1]) else { return nil }; return CLLocationCoordinate2D(latitude: lat, longitude: lon)
            }
            if inLineString { coordinates.append(contentsOf: points) } else if let first = points.first { waypoints.append(ImportedWaypoint(name: currentName.isEmpty ? "Punto" : currentName, coordinate: first)) }
        }
        if name == "linestring" { inLineString = false }
        buffer = ""; element = ""
    }
}
