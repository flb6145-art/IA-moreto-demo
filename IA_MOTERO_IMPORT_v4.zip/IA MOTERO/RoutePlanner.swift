import Foundation
import MapKit
import CoreLocation

@MainActor
final class RoutePlanner: ObservableObject {
    @Published var isCalculating = false
    @Published var errorMessage: String?

    func calculate(points: [CLLocationCoordinate2D], preferences: RoutePreferences) async -> RouteResponse? {
        guard points.count >= 2 else { return nil }
        isCalculating = true
        errorMessage = nil
        defer { isCalculating = false }

        // Apple Maps provides a fully local fallback. If a production backend is configured,
        // it can later replace this calculation to support motorcycle-specific winding/scenic routing.
        do {
            var combinedCoordinates: [CLLocationCoordinate2D] = []
            var combinedSteps: [RouteStep] = []
            var distance = 0.0
            var duration = 0.0

            for index in 0..<(points.count - 1) {
                let request = MKDirections.Request()
                request.source = MKMapItem(placemark: MKPlacemark(coordinate: points[index]))
                request.destination = MKMapItem(placemark: MKPlacemark(coordinate: points[index + 1]))
                request.transportType = .automobile
                request.requestsAlternateRoutes = false
                request.routePreference = .fastest
                if #available(iOS 16.0, *) {
                    request.avoidsHighways = preferences.avoidHighways
                    request.avoidsTolls = preferences.avoidTolls
                }

                let response = try await MKDirections(request: request).calculate()
                guard let route = response.routes.first else { throw URLError(.cannotParseResponse) }
                let converted = RouteResponse.from(mapRoute: route)
                distance += converted.distanceKm
                duration += converted.durationMin
                if combinedCoordinates.isEmpty { combinedCoordinates.append(contentsOf: converted.geometry.coordinates2D) }
                else { combinedCoordinates.append(contentsOf: converted.geometry.coordinates2D.dropFirst()) }
                combinedSteps.append(contentsOf: converted.steps)
            }

            let geometry = Geometry(type: "LineString", coordinates: combinedCoordinates.map { [$0.longitude, $0.latitude] })
            return RouteResponse(distanceKm: distance, durationMin: duration, geometry: geometry, steps: combinedSteps)
        } catch {
            errorMessage = "No se ha podido calcular la ruta. Comprueba la conexión y el destino."
            return nil
        }
    }
}
