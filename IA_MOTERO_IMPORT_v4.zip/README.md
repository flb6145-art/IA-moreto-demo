# 🏍️ IA MOTERO — versión final iOS

Esta entrega deja un **MVP funcional y autónomo en el iPhone**, sin depender de un backend para las funciones básicas de navegación.

## Incluye

- 🗺️ Mapa Apple Maps / MapKit.
- 📍 GPS de navegación y trazado de la ruta en tiempo real.
- 🔎 Búsqueda de destinos.
- 🎙️ Entrada de destino por voz en español.
- 🧭 Cálculo de rutas con Apple Maps.
- 🚧 Evitar autopistas y peajes.
- 🏍️ Preferencias de conducción: curvas, panorámica y rapidez (las dos primeras quedan preparadas para el motor específico de IA MOTERO; MapKit se utiliza como respaldo).
- ➕ **Múltiples paradas** en una misma ruta.
- ➡️ Navegación giro a giro.
- 🔊 Instrucciones habladas en español.
- 📏 Distancia hasta la maniobra, kilómetros restantes y ETA.
- ⚠️ Detección de salida de ruta mediante distancia a la geometría.
- 🔄 **Recalculo automático local con MapKit**, sin servidor propio.
- ⛽ Gasolineras, restaurantes y talleres próximos a la ruta.
- 🌙 Preparación para ubicación en segundo plano.
- 🔐 Cliente de backend opcional sin claves privadas embebidas.
- 📱 Proyecto Xcode incluido, listo para abrir en Xcode.

## Abrir en Xcode

1. Abre `IA MOTERO.xcodeproj` en un Mac con Xcode.
2. Selecciona el target `IA MOTERO`.
3. Elige tu equipo en **Signing & Capabilities**.
4. Ejecuta en un **iPhone físico** para probar GPS, Bluetooth y voz.
5. Para navegación con pantalla bloqueada, comprueba **Background Modes → Location updates** y concede permiso de ubicación en segundo plano cuando iOS lo solicite.

## Qué funciona sin backend

La búsqueda, cálculo de ruta, navegación, voz, recalculo, paradas y servicios utilizan APIs de Apple y funcionan sin configurar un servidor propio.

## Backend opcional

`APIClient.swift` permite conectar posteriormente el motor específico de IA MOTERO. El backend puede implementar:

- `POST /api/route`
- `POST /api/route/recalculate`
- `GET /api/services/along-route`
- interpretación avanzada de órdenes de voz/texto
- optimización de curvas, carreteras panorámicas y preferencias personales

No se ha inventado ningún servidor ni clave de proveedor: `api.example.com` es deliberadamente un marcador.

## Importante

Para publicar en App Store aún hay pasos externos al código: cuenta Apple Developer, firma, iconos/capturas, política de privacidad, pruebas en diferentes iPhone, revisión de permisos y validación real de navegación. El proyecto está preparado para esa fase, pero esos trámites no pueden hacerse desde este archivo por sí solo.
