# Backend contract

POST /api/ai/parse-route
{"prompt":"350 km desde Sant Joan de Vilatorrada, muchas curvas, evitando autopistas, pasando por Tremp y Sort"}

Respuesta:
{"origen":"Sant Joan de Vilatorrada","destino":"Sort","puntos":["Tremp"],"distancia_km":350,"evitar_autopistas":true,"preferencia_curvas":"alta"}

GET /api/geocode?q=Tremp
Respuesta: [{"name":"Tremp","lat":42.166,"lon":0.894}]

POST /api/route
{"points":[{"lat":41.73,"lon":1.82},{"lat":42.16,"lon":0.89}]}

Respuesta:
{"distanceKm":320,"durationMin":402,"geometry":{"type":"LineString","coordinates":[[1.82,41.73],[0.89,42.16]]},"steps":[{"name":"C-14","distance":1200,"duration":90,"maneuver":{"instruction":"Gira a la derecha","type":"turn","modifier":"right"}}]}

GET /api/services?type=fuel&lat=41.73&lon=1.82&radius=7000
