# IA MOTERO — contrato de backend

## POST /api/route

Request:
```json
{
  "points": [
    {"lat": 41.728, "lon": 1.823},
    {"lat": 42.136, "lon": 2.765}
  ],
  "preferences": {
    "avoidHighways": true,
    "avoidTolls": false,
    "windingRoads": true,
    "scenic": true,
    "fastest": false
  }
}
```

Response:
```json
{
  "distanceKm": 286.4,
  "durationMin": 352,
  "geometry": {
    "type": "LineString",
    "coordinates": [[1.823,41.728],[1.900,41.760]]
  },
  "steps": [
    {
      "name": "Gira a la derecha",
      "distance": 180,
      "duration": 18,
      "maneuver": {"instruction":"Gira a la derecha hacia BV-3008","type":"turn","modifier":"right"},
      "location": [1.825,41.729]
    }
  ]
}
```

## POST /api/route/recalculate

Debe aceptar la posición actual y el destino y devolver una nueva `RouteResponse`.

Recomendación: aplicar un límite por usuario/dispositivo para evitar recalcular continuamente cuando el GPS rebota.

## GET /api/services/along-route

Ejemplo conceptual:
`/api/services/along-route?type=fuel&distance=5000`

Tipos previstos:
- fuel
- restaurant
- workshop
- hotel
- charging

## Motor de ruta para moto

El backend debería poder ponderar:
- porcentaje de autopista
- porcentaje de carreteras secundarias
- número/longitud de curvas
- desnivel
- tráfico si el proveedor lo permite
- peajes
- firme/carretera
- puntos de interés
- preferencias del usuario

Las claves de proveedores externos y de IA deben permanecer exclusivamente en servidor.
